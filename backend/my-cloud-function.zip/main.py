import logging
from typing import Tuple
from google.cloud import firestore
from flask import jsonify, Request

# Initialize logger
logging.basicConfig(level=logging.INFO)

def get_current_number(db: firestore.Client, number_ref: firestore.DocumentReference) -> int:
    """
    Retrieves the current visitor number from Firestore.

    Args:
        db: Firestore client instance.
        number_ref: Reference to the Firestore document.

    Returns:
        The current number of visitors or raises a specific exception if an error occurs.
    """
    try:
        doc = number_ref.get()
        if doc.exists:
            return int(doc.to_dict().get('count', 0))
    except firestore.exceptions.NotFound as e:
        logging.error("Firestore document not found: %s", e)
        raise
    except Exception as e:
        logging.error("Error retrieving visitor number: %s", e)
        raise

def save_visitor_count(db: firestore.Client, number_ref: firestore.DocumentReference, current_number: int) -> None:
    """
    Updates the visitor count in Firestore.

    Args:
        db: Firestore client instance.
        number_ref: Reference to the Firestore document.
        current_number: Updated count of visitors.

    Raises specific exceptions during the update process if errors occur.
    """
    try:
        number_ref.set({'count': current_number})
    except Exception as e:
        logging.error("Error saving visitor count: %s", e)
        raise

def current_number_visitors(request: Request) -> Tuple[dict, int, dict]:
    """
    Handles the incoming request to get and update the current number of visitors.

    Args:
        request: The incoming request object.

    Returns:
        A JSON response containing the new number of visitors, the HTTP status code, and headers.
    """
    try:
        db = firestore.Client()
        number_ref = db.collection('visitors').document('visitors_id')

        current_number = get_current_number(db, number_ref)
        new_number = current_number + 1
        save_visitor_count(db, number_ref, new_number)

        data = {'new_number': new_number}
        headers = {'Access-Control-Allow-Origin': '*'}

        return jsonify(data), 200, headers
    except Exception as e:
        logging.error("Error in current_number_visitors: %s", e)
        return jsonify({'error': 'An internal error occurred'}), 500
